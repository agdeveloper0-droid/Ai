import os
import google.generativeai as genai
from flask import Blueprint, request, jsonify
from dotenv import load_dotenv

# .env फाइल से API की लोड करें
load_dotenv()

novel_bp = Blueprint('novel', __name__)

# Gemini AI को कॉन्फ़िगर करें
try:
    api_key = os.environ.get("GOOGLE_API_KEY")
    if not api_key or api_key == "your_api_key_here":
        print("चेतावनी: API की सेट नहीं है. कृपया .env फाइल में अपनी Gemini API Key डालें.")
        model = None
    else:
        genai.configure(api_key=api_key)
        # Gemini 1.5 Flash मॉडल का उपयोग करें
        model = genai.GenerativeModel('gemini-1.5-flash')
        print("✅ Gemini 1.5 Flash मॉडल सफलतापूर्वक लोड हो गया है.")
except Exception as e:
    print(f"❌ AI मॉडल को कॉन्फ़िगर करने में त्रुटि: {e}")
    model = None

@novel_bp.route('/generate-novel', methods=['POST'])
def generate_novel():
    """नॉवेल जेनरेशन API एंडपॉइंट"""
    
    if not model:
        return jsonify({
            "error": "AI मॉडल लोड नहीं हुआ है. कृपया .env फाइल में अपनी Gemini API Key सेट करें."
        }), 500

    try:
        data = request.json
        
        # यूजर से मिली जानकारी को validate करें
        required_fields = ['topic', 'audience', 'synopsis', 'num_chapters']
        for field in required_fields:
            if not data.get(field):
                return jsonify({"error": f"'{field}' फील्ड आवश्यक है."}), 400
        
        topic = data.get('topic')
        audience = data.get('audience')
        synopsis = data.get('synopsis')
        num_chapters = int(data.get('num_chapters', 3))
        min_words = int(data.get('min_words_per_chapter', 500))

        # चैप्टर की संख्या को सीमित करें (API limits के लिए)
        if num_chapters > 10:
            return jsonify({"error": "अधिकतम 10 चैप्टर तक ही समर्थित हैं."}), 400

        print(f"📚 नॉवेल जेनरेशन शुरू: {topic} ({num_chapters} चैप्टर)")

        # 1. आउटलाइन बनाना
        print("📝 आउटलाइन बना रहे हैं...")
        prompt_outline = f"""
        एक {topic} विषय पर आधारित नॉवेल के लिए {num_chapters} अध्यायों की एक विस्तृत आउटलाइन बनाओ.
        
        टारगेट ऑडियंस: {audience}
        कहानी का सार: {synopsis}
        
        आउटपुट फॉर्मेट:
        चैप्टर 1: [टाइटल] - [संक्षिप्त विवरण]
        चैप्टर 2: [टाइटल] - [संक्षिप्त विवरण]
        ...
        
        हर चैप्टर का टाइटल रोचक और कहानी को आगे बढ़ाने वाला होना चाहिए.
        """
        outline_response = model.generate_content(prompt_outline)
        outline = outline_response.text

        # 2. पात्र बनाना
        print("👥 मुख्य पात्र बना रहे हैं...")
        prompt_characters = f"""
        कहानी '{synopsis}' के लिए मुख्य पात्रों की प्रोफाइल बनाओ.
        
        निम्नलिखित के लिए विस्तृत जानकारी दें:
        1. मुख्य पात्र (Protagonist): नाम, उम्र, व्यक्तित्व, पृष्ठभूमि, लक्ष्य
        2. विरोधी पात्र (Antagonist): नाम, उम्र, व्यक्तित्व, मकसद
        3. सहायक पात्र (2-3): नाम और उनकी भूमिका
        
        पात्र {audience} ऑडियंस के लिए उपयुक्त होने चाहिए.
        """
        characters_response = model.generate_content(prompt_characters)
        characters = characters_response.text

        # 3. दुनिया का निर्माण (World Building)
        print("🌍 कहानी की दुनिया बना रहे हैं...")
        prompt_world = f"""
        कहानी '{synopsis}' के लिए सेटिंग और दुनिया का विस्तृत विवरण तैयार करो.
        
        शामिल करें:
        1. समय और स्थान (कब और कहाँ)
        2. माहौल और वातावरण
        3. सामाजिक/राजनीतिक स्थिति (यदि प्रासंगिक हो)
        4. विशेष नियम या तत्व (यदि फंतासी/साइंस फिक्शन है)
        
        यह {topic} विषय के अनुकूल होना चाहिए.
        """
        world_response = model.generate_content(prompt_world)
        world_details = world_response.text

        # 4. चैप्टर-वाइज लिखना
        print("📖 चैप्टर लिख रहे हैं...")
        novel_chapters = []
        
        for i in range(1, num_chapters + 1):
            print(f"✍️ चैप्टर {i}/{num_chapters} लिख रहे हैं...")
            
            prompt_chapter = f"""
            अब नॉवेल का चैप्टर {i} लिखो.
            
            संदर्भ जानकारी:
            - कहानी का सार: {synopsis}
            - आउटलाइन: {outline}
            - मुख्य पात्र: {characters}
            - दुनिया की जानकारी: {world_details}
            
            निर्देश:
            1. इस चैप्टर को कम से कम {min_words} शब्दों में लिखो
            2. कहानी को आगे बढ़ाते हुए रोचक और engaging बनाओ
            3. संवाद (dialogue) का उपयोग करो
            4. दृश्यों का वर्णन विस्तार से करो
            5. चैप्टर का अंत अगले चैप्टर के लिए curiosity बनाए
            
            चैप्टर {i} लिखना शुरू करो:
            """
            
            chapter_response = model.generate_content(prompt_chapter)
            chapter_content = chapter_response.text
            
            novel_chapters.append({
                "chapter": i,
                "title": f"चैप्टर {i}",
                "content": chapter_content,
                "word_count": len(chapter_content.split())
            })

        print("✅ नॉवेल जेनरेशन पूर्ण!")

        # JSON फॉर्मेट में पूरा रिजल्ट वापस भेजें
        return jsonify({
            "success": True,
            "novel": {
                "title": f"{topic.title()} - एक AI नॉवेल",
                "synopsis": synopsis,
                "target_audience": audience,
                "outline": outline,
                "characters": characters,
                "world_details": world_details,
                "chapters": novel_chapters,
                "total_chapters": len(novel_chapters),
                "total_words": sum(chapter["word_count"] for chapter in novel_chapters)
            }
        })

    except ValueError as ve:
        return jsonify({"error": f"डेटा वैलिडेशन त्रुटि: {str(ve)}"}), 400
    except Exception as e:
        print(f"❌ कंटेंट जेनरेट करते समय त्रुटि: {e}")
        return jsonify({"error": f"AI से जवाब प्राप्त करने में त्रुटि हुई: {str(e)}"}), 500

@novel_bp.route('/health', methods=['GET'])
def health_check():
    """API स्वास्थ्य जांच"""
    return jsonify({
        "status": "healthy",
        "ai_model_loaded": model is not None,
        "message": "AI Novel Writer API चालू है!"
    })

