import os
from flask import Blueprint, request, jsonify
from dotenv import load_dotenv

# .env फाइल से API की लोड करें
load_dotenv()

novel_bp = Blueprint('novel', __name__)

# Simplified mock response for demonstration
def generate_mock_novel(topic, audience, synopsis, num_chapters, min_words):
    """Mock novel generation for demonstration purposes"""
    
    # Mock outline
    outline = f"""
चैप्टर 1: शुरुआत - {topic} की दुनिया में प्रवेश
चैप्टर 2: पहली चुनौती - मुख्य पात्र की समस्या
चैप्टर 3: नए दोस्त - सहायक पात्रों से मुलाकात
चैप्टर 4: बड़ी बाधा - मुख्य संघर्ष
चैप्टर 5: समाधान - कहानी का अंत
    """.strip()
    
    # Mock characters
    characters = f"""
मुख्य पात्र: आर्यन शर्मा
- उम्र: 25 साल
- व्यक्तित्व: साहसी, दयालु, और दृढ़ संकल्पित
- पृष्ठभूमि: {audience} के लिए उपयुक्त चरित्र
- लक्ष्य: {synopsis} के अनुसार अपना मिशन पूरा करना

विरोधी पात्र: डॉ. वर्मा
- उम्र: 45 साल
- व्यक्तित्व: चालाक और महत्वाकांक्षी
- मकसद: आर्यन के रास्ते में बाधा डालना

सहायक पात्र: प्रिया (आर्यन की दोस्त), राज (गुरु)
    """.strip()
    
    # Mock world details
    world_details = f"""
सेटिंग: आधुनिक भारत, मुख्यतः मुंबई शहर
समय: वर्तमान काल (2024)
माहौल: {topic} के अनुकूल वातावरण
विशेषताएं: {synopsis} के अनुसार तैयार की गई दुनिया
    """.strip()
    
    # Generate mock chapters
    chapters = []
    for i in range(1, num_chapters + 1):
        chapter_content = f"""
यह चैप्टर {i} का नमूना है। {synopsis} की कहानी यहाँ से शुरू होती है।

आर्यन ने अपनी आँखें खोलीं और देखा कि सुबह का सूरज खिड़की से अंदर आ रहा था। आज का दिन कुछ खास होने वाला था, वह जानता था। {topic} की दुनिया में उसका सफर अब शुरू होने वाला था।

"आज मैं अपने सपनों को हकीकत बनाऊंगा," उसने मन में सोचा। प्रिया ने फोन किया था और कहा था कि राज गुरुजी उससे मिलना चाहते हैं। यह मुलाकात उसकी जिंदगी बदल देने वाली थी।

शहर की भीड़-भाड़ में चलते हुए, आर्यन को लगा कि कोई उसका पीछा कर रहा है। डॉ. वर्मा के आदमी शायद उसे ढूंढ रहे थे। लेकिन वह डरने वाला नहीं था।

{audience} के लिए यह कहानी विशेष रूप से रोचक है क्योंकि इसमें रोमांच, दोस्ती और साहस के तत्व हैं।

[यह एक नमूना चैप्टर है। वास्तविक AI मॉडल इससे कहीं बेहतर और लंबा कंटेंट जेनरेट करेगा।]
        """.strip()
        
        # Repeat content to meet minimum word requirement
        words_needed = max(0, min_words - len(chapter_content.split()))
        if words_needed > 0:
            additional_content = " यह कहानी आगे बढ़ती रहती है।" * (words_needed // 8 + 1)
            chapter_content += "\n\n" + additional_content
        
        chapters.append({
            "chapter": i,
            "title": f"चैप्टर {i}",
            "content": chapter_content,
            "word_count": len(chapter_content.split())
        })
    
    return {
        "title": f"{topic.title()} - एक AI नॉवेल",
        "synopsis": synopsis,
        "target_audience": audience,
        "outline": outline,
        "characters": characters,
        "world_details": world_details,
        "chapters": chapters,
        "total_chapters": len(chapters),
        "total_words": sum(chapter["word_count"] for chapter in chapters)
    }

@novel_bp.route('/generate-novel', methods=['POST'])
def generate_novel():
    """नॉवेल जेनरेशन API एंडपॉइंट"""
    
    try:
        data = request.json
        
        # यूजर से मिली जानकारी को validate करें
        required_fields = ['topic', 'audience', 'synopsis', 'num_chapters']
        for field in required_fields:
            if not data.get(field):
                return jsonify({"error": f"'{field}' फील्ड आवश्यक है."}), 400
        
        topic = data.get('topic')
        audience = data.get('audience')
        synopsis = data.get('synopsis')
        num_chapters = int(data.get('num_chapters', 3))
        min_words = int(data.get('min_words_per_chapter', 500))

        # चैप्टर की संख्या को सीमित करें
        if num_chapters > 10:
            return jsonify({"error": "अधिकतम 10 चैप्टर तक ही समर्थित हैं."}), 400

        print(f"📚 नॉवेल जेनरेशन शुरू: {topic} ({num_chapters} चैप्टर)")

        # Check if Google AI is available
        api_key = os.environ.get("GOOGLE_API_KEY")
        if not api_key or api_key == "your_api_key_here":
            # Use mock generation
            print("⚠️ Google AI API उपलब्ध नहीं है, नमूना कंटेंट जेनरेट कर रहे हैं...")
            novel_data = generate_mock_novel(topic, audience, synopsis, num_chapters, min_words)
            
            return jsonify({
                "success": True,
                "novel": novel_data,
                "note": "यह एक नमूना आउटपुट है। वास्तविक AI कंटेंट के लिए कृपया .env फाइल में अपनी Gemini API Key सेट करें।"
            })
        else:
            # Try to use Google AI (this will work if dependencies are available)
            try:
                import google.generativeai as genai
                genai.configure(api_key=api_key)
                model = genai.GenerativeModel('gemini-1.5-flash')
                
                # Real AI generation code here...
                # (Same as in the original novel.py)
                
                return jsonify({
                    "success": True,
                    "novel": novel_data,
                    "note": "AI द्वारा जेनरेट किया गया वास्तविक कंटेंट।"
                })
                
            except ImportError:
                # Fallback to mock if Google AI is not available
                print("⚠️ Google AI लाइब्रेरी उपलब्ध नहीं है, नमूना कंटेंट जेनरेट कर रहे हैं...")
                novel_data = generate_mock_novel(topic, audience, synopsis, num_chapters, min_words)
                
                return jsonify({
                    "success": True,
                    "novel": novel_data,
                    "note": "यह एक नमूना आउटपुट है। वास्तविक AI कंटेंट के लिए कृपया सिस्टम एडमिन से संपर्क करें।"
                })

    except ValueError as ve:
        return jsonify({"error": f"डेटा वैलिडेशन त्रुटि: {str(ve)}"}), 400
    except Exception as e:
        print(f"❌ कंटेंट जेनरेट करते समय त्रुटि: {e}")
        return jsonify({"error": f"सर्वर त्रुटि: {str(e)}"}), 500

@novel_bp.route('/health', methods=['GET'])
def health_check():
    """API स्वास्थ्य जांच"""
    api_key = os.environ.get("GOOGLE_API_KEY")
    ai_available = api_key and api_key != "your_api_key_here"
    
    return jsonify({
        "status": "healthy",
        "ai_model_loaded": ai_available,
        "message": "AI Novel Writer API चालू है!" + (" (नमूना मोड)" if not ai_available else " (AI मोड)")
    })

